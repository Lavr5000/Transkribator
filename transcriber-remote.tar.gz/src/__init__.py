"""WhisperTyping - Local Voice Transcription App"""
__version__ = "1.0.0"
